# KlirSecure — Authentification des comptes (Cloudflare Workers + D1)

Ce dépôt contient maintenant une **authentification réelle côté serveur** : inscription, connexion, déconnexion, sessions, changement de mot de passe, limitation de débit et proxy d'audit durci. L'application ne s'ouvre plus sans compte valide.

## Architecture

```
public/            → fichiers statiques servis par le Worker (index.html, app.js, auth.js, core.js…)
src/worker.js      → Cloudflare Worker : API /api/auth/* + /api/proxy + assets
schema.sql         → tables D1 (users, sessions, rate_limit)
wrangler.jsonc     → configuration de déploiement
```

## Sécurité implémentée

- **Mots de passe** : PBKDF2-SHA256, 210 000 itérations (configurable via `PBKDF2_ITERATIONS`), sel aléatoire unique de 16 octets, comparaison en temps constant.
- **Sessions** : jeton aléatoire 256 bits, seul son SHA-256 est stocké en base ; cookie `__Host-ks_session` (HttpOnly, Secure, SameSite=Lax, Path=/, sans Domain) ; durée 7 jours avec renouvellement glissant et rotation du jeton.
- **Connexion** : messages d'erreur génériques (anti-énumération de comptes), vérification factice si le compte n'existe pas (anti timing attack).
- **Limitation de débit** : 10 essais / 15 min par courriel, 30 / 15 min par IP → HTTP 429.
- **Anti-CSRF** : cookie SameSite=Lax + vérification de l'header `Origin` + header custom `X-Requested-With` exigé sur les POST.
- **Changement de mot de passe** : exige le mot de passe actuel, invalide **toutes** les sessions existantes, en délivre une nouvelle.
- **Headers de sécurité** sur toutes les réponses : CSP stricte (`script-src 'self'`), X-Frame-Options DENY, nosniff, Referrer-Policy, Permissions-Policy, `Cache-Control: no-store` sur l'API.
- **Proxy d'audit durci** (remplace l'ancien proxy Netlify ouvert, risque SSRF) : session requise, GET/HEAD uniquement, protocoles http/https seulement, blocage des hôtes privés (127.x, 10.x, 192.168.x, 169.254.x incluant les metadata cloud, localhost, *.internal…), timeout 18 s, réponse plafonnée à ~400 Ko, redirections validées à chaque saut (max 4). Les headers de sécurité de la cible auditée sont renvoyés préfixés `X-KS-H-*` pour que l'audit des headers fonctionne.
- **Politique de mots de passe** : 10 caractères minimum, au moins une lettre et un chiffre, 128 maximum.

## Déploiement

### 1. Créer la base D1

```bash
npx wrangler login
npx wrangler d1 create klirsecure
```

Copier le `database_id` affiché dans `wrangler.jsonc` (remplacer `A_COMPLETER_APRES_CREATION_D1`).

### 2. Initialiser le schéma

```bash
npx wrangler d1 execute klirsecure --remote --file schema.sql
```

### 3. Déployer

```bash
npx wrangler deploy
```

Le Worker obtient une URL `https://klirsecure.<ton-sous-domaine>.workers.dev`. Premier compte créé via « Créer un compte » = administrateur.

### 4. Domaine personnalisé (klirsecure.klirline.ca)

Dans le tableau de bord Cloudflare : **Workers & Pages → klirsecure → Settings → Domains & Routes → Add → Custom domain** → `klirsecure.klirline.ca`.

**Attention** : ce sous-domaine sert actuellement le site vitrine « Klirline Inc. » (Next.js). Attacher le Worker en domaine personnalisé remplacera ce site à cette adresse — choisis un sous-domaine différent (ex. `app.klirline.ca` ou `audit.klirline.ca`) si tu veux garder la vitrine.

### Alternative : déploiement via GitHub

Tableau de bord Cloudflare → Workers & Pages → Create → connecter le dépôt GitHub `Klirline-Secure` (Workers Builds exécute `npx wrangler deploy` automatiquement à chaque push). Créer d'abord la base D1 et renseigner le `database_id` dans `wrangler.jsonc` avant le premier build.

## Développement local

```bash
npx wrangler d1 execute klirsecure --local --file schema.sql
npx wrangler dev
```

Note : en local (`http://localhost:8787`), le cookie `__Host-` exige `Secure` — Chrome et Firefox l'acceptent sur localhost. Sinon, tester via l'URL workers.dev.

## Endpoints API

| Méthode | Route                    | Description                                            |
|---------|--------------------------|--------------------------------------------------------|
| POST    | `/api/auth/register`     | Créer un compte (courriel, mot de passe, nom)          |
| POST    | `/api/auth/login`        | Connexion (cookie de session)                          |
| POST    | `/api/auth/logout`       | Déconnexion                                            |
| GET     | `/api/auth/me`           | Session courante                                       |
| POST    | `/api/auth/change-password` | Changer le mot de passe (invalide toutes les sessions) |
| GET     | `/api/proxy?url=…`      | Proxy d'audit (session requise, GET passif)            |

## Limites actuelles (assumées pour ce MVP)

- Les données d'audit (rapports, organisations, rôles locaux, quotas) restent stockées côté navigateur (localStorage) : l'authentification protège l'accès à l'application, mais le multi-tenant serveur n'est pas encore en place.
- Le rôle (admin/auditeur/lecteur) provient du compte serveur ; les « membres » ajoutés dans l'onglet Organisation restent une fonctionnalité locale de démonstration.
- Pas de vérification d'adresse courriel ni de réinitialisation de mot de passe par e-mail (aucun service d'envoi configuré) — à ajouter avec Email Routing / Resend si besoin.
- Le proxy ne peut pas résoudre le DNS avant connexion (limite Workers) : les noms de domaine publics redirigeant vers des IP privées (DNS rebinding) ne sont pas filtrables ; les IP littérales privées, elles, sont bloquées.

## Tests

41 tests automatisés (inscription, session, déconnexion, erreurs génériques, rate limiting, CSRF, changement de mot de passe avec invalidation des sessions, proxy durci, headers, stockage) — tous passent.
