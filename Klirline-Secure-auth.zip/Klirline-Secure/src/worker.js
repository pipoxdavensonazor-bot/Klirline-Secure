// ============================================================================
// KlirSecure — Cloudflare Worker
// Authentification des comptes (D1 + PBKDF2 + sessions serveur)
// + service des fichiers statiques + proxy d'audit durci
// ----------------------------------------------------------------------------
// Variables d'environnement :
//   DB                (binding D1, obligatoire)
//   ASSETS            (binding Assets, obligatoire)
//   PBKDF2_ITERATIONS (optionnel, défaut 210000)
// ============================================================================

const ITERATIONS_DEFAULT = 210000;
const SESSION_TTL_S = 7 * 24 * 3600;            // 7 jours
const SESSION_RENEW_THRESHOLD_S = 3 * 24 * 3600; // renouvellement glissant sous 3 jours restants
const COOKIE_NAME = "__Host-ks_session";

const RATE_WINDOW_MS = 15 * 60 * 1000; // fenêtre de 15 minutes
const RATE_MAX_PER_EMAIL = 10;           // essais de connexion par courriel / fenêtre
const RATE_MAX_PER_IP = 30;              // essais de connexion par IP / fenêtre

const MAX_BODY_BYTES = 2048;

const PROXY_MAX_BYTES = 420000;     // ~400 Ko, comme le front (slice 400000)
const PROXY_TIMEOUT_MS = 18000;
const PROXY_MAX_REDIRECTS = 4;

const SECURITY_HEADERS = {
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "DENY",
  "Referrer-Policy": "strict-origin-when-cross-origin",
  "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
  "Content-Security-Policy":
    "default-src 'self'; " +
    "script-src 'self'; " +
    "style-src 'self' 'unsafe-inline'; " +
    "img-src 'self' data:; " +
    "connect-src 'self' https://api.osv.dev https://api.github.com https://raw.githubusercontent.com; " +
    "object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'",
};

const EMAIL_RE = /^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,24}$/;

// --------------------------------------------------------------------------
// Utilitaires crypto / encodage
// --------------------------------------------------------------------------
const enc = new TextEncoder();

function b64(buf) {
  let s = "";
  const b = new Uint8Array(buf);
  for (let i = 0; i < b.length; i++) s += String.fromCharCode(b[i]);
  return btoa(s);
}

function b64url(buf) {
  return b64(buf).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function randomToken() {
  return b64url(crypto.getRandomValues(new Uint8Array(32))); // 256 bits
}

function newId() {
  return crypto.randomUUID();
}

async function sha256Hex(str) {
  const d = await crypto.subtle.digest("SHA-256", enc.encode(str));
  return [...new Uint8Array(d)].map(b => b.toString(16).padStart(2, "0")).join("");
}

/** Comparaison en temps constant (anti timing attack). */
function constEq(a, b) {
  const A = typeof a === "string" ? enc.encode(a) : new Uint8Array(a);
  const B = typeof b === "string" ? enc.encode(b) : new Uint8Array(b);
  if (A.length !== B.length || A.length === 0) return false;
  let diff = 0;
  for (let i = 0; i < A.length; i++) diff |= A[i] ^ B[i];
  return diff === 0;
}

function iterations(env) {
  const n = parseInt(String(env && env.PBKDF2_ITERATIONS || ""), 10);
  return Number.isFinite(n) && n >= 100000 ? n : ITERATIONS_DEFAULT;
}

async function pbkdf2(password, salt, iter) {
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  return new Uint8Array(await crypto.subtle.deriveBits(
    { name: "PBKDF2", hash: "SHA-256", salt, iterations: iter }, key, 256));
}

/** Format stocké : pbkdf2$<iterations>$<salt b64>$<hash b64> (migrable). */
async function hashPassword(password, env) {
  const iter = iterations(env);
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const hash = await pbkdf2(password, salt, iter);
  return ["pbkdf2", iter, b64(salt), b64(hash)].join("$");
}

async function verifyPassword(password, stored) {
  try {
    const parts = String(stored).split("$");
    if (parts.length !== 4 || parts[0] !== "pbkdf2") return false;
    const iter = parseInt(parts[1], 10);
    if (!Number.isFinite(iter) || iter < 1) return false;
    const saltBin = atob(parts[2]);
    const salt = new Uint8Array(saltBin.length);
    for (let i = 0; i < saltBin.length; i++) salt[i] = saltBin.charCodeAt(i);
    const wantB = atob(parts[3]);
    const want = new Uint8Array(wantB.length);
    for (let i = 0; i < wantB.length; i++) want[i] = wantB.charCodeAt(i);
    const got = await pbkdf2(password, salt, iter);
    return constEq(got, want);
  } catch (e) {
    return false;
  }
}

// --------------------------------------------------------------------------
// Accès D1
// --------------------------------------------------------------------------
async function q1(env, sql, params) {
  return env.DB.prepare(sql).bind(...params).first();
}
async function run(env, sql, params) {
  return env.DB.prepare(sql).bind(...params).run();
}

// --------------------------------------------------------------------------
// Réponses HTTP
// --------------------------------------------------------------------------
function json(data, status, extraHeaders) {
  const h = {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    ...SECURITY_HEADERS,
    ...(extraHeaders || {}),
  };
  return new Response(JSON.stringify(data), { status: status || 200, headers: h });
}

function setCookie(token, maxAge) {
  // Préfixe __Host- : exige Secure + Path=/ + pas de Domain (anti sous-domaine)
  return `${COOKIE_NAME}=${token}; Max-Age=${maxAge}; Path=/; Secure; HttpOnly; SameSite=Lax`;
}
function clearCookieHeader() {
  return `${COOKIE_NAME}=; Max-Age=0; Path=/; Secure; HttpOnly; SameSite=Lax`;
}

function parseCookies(req) {
  const out = {};
  const raw = req.headers.get("cookie") || "";
  raw.split(";").forEach(p => {
    const i = p.indexOf("=");
    if (i > 0) out[p.slice(0, i).trim()] = p.slice(i + 1).trim();
  });
  return out;
}

function clientIp(req) {
  return (req.headers.get("cf-connecting-ip") || "0.0.0.0").trim();
}

// --------------------------------------------------------------------------
// Sessions
// --------------------------------------------------------------------------
function publicUser(row) {
  // Ne JAMAIS exposer password_hash / salt / jetons
  return { id: row.id, email: row.email, name: row.name, role: row.role };
}

async function createSession(env, req, userId) {
  const token = randomToken();
  const tokenHash = await sha256Hex(token);
  const now = Math.floor(Date.now() / 1000);
  await run(env,
    "INSERT INTO sessions(token_hash, user_id, created_at, expires_at, ip, ua) VALUES(?,?,?,?,?,?)",
    [tokenHash, userId, now, now + SESSION_TTL_S, clientIp(req), (req.headers.get("user-agent") || "").slice(0, 200)]);
  return { token, tokenHash };
}

/** Retourne { tokenHash, user } ou null. Renouvelle l'expiration (glissante). */
async function getSession(env, req) {
  const token = parseCookies(req)[COOKIE_NAME];
  if (!token || token.length < 20 || token.length > 128) return null;
  const tokenHash = await sha256Hex(token);
  const now = Math.floor(Date.now() / 1000);
  const row = await q1(env,
    "SELECT s.token_hash AS th, s.expires_at AS exp, u.id, u.email, u.name, u.role, u.status " +
    "FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.expires_at > ?",
    [tokenHash, now]);
  if (!row || row.status !== "active") return null;
  if (row.exp - now < SESSION_RENEW_THRESHOLD_S) {
    // Rotation du jeton au renouvellement (anti fixation / vol long terme)
    await run(env, "DELETE FROM sessions WHERE token_hash = ?", [tokenHash]);
    const fresh = await createSession(env, req, row.id);
    return { tokenHash: fresh.tokenHash, user: { id: row.id, email: row.email, name: row.name, role: row.role }, rotatedToken: fresh.token };
  }
  return { tokenHash, user: { id: row.id, email: row.email, name: row.name, role: row.role } };
}

async function deleteAllSessions(env, userId) {
  await run(env, "DELETE FROM sessions WHERE user_id = ?", [userId]);
}

// --------------------------------------------------------------------------
// Limitation de débit (rate limiting)
// --------------------------------------------------------------------------
async function rateHit(env, key, max) {
  const ws = Math.floor(Date.now() / RATE_WINDOW_MS);
  const row = await q1(env,
    "INSERT INTO rate_limit(k, window_start, count) VALUES(?,?,1) " +
    "ON CONFLICT(k) DO UPDATE SET count = CASE WHEN window_start = ? THEN count + 1 ELSE 1 END, window_start = ? " +
    "RETURNING count",
    [key, ws, ws, ws]);
  return (row ? row.count : 1) <= max;
}

async function rateReset(env, key) {
  await run(env, "UPDATE rate_limit SET count = 0 WHERE k = ?", [key]);
}

async function housekeeping(env) {
  if (Math.random() < 0.1) {
    const nowMs = Date.now();
    const nowS = Math.floor(nowMs / 1000);
    try {
      await run(env, "DELETE FROM rate_limit WHERE window_start < ?", [Math.floor(nowMs / RATE_WINDOW_MS) - 2]);
      await run(env, "DELETE FROM sessions WHERE expires_at < ?", [nowS]);
    } catch (e) { /* non bloquant */ }
  }
}

// --------------------------------------------------------------------------
// Validation des entrées
// --------------------------------------------------------------------------
function normEmail(e) {
  return String(e || "").trim().toLowerCase().slice(0, 254);
}

function validEmail(e) {
  return EMAIL_RE.test(e);
}

function validPassword(p) {
  if (typeof p !== "string" || p.length < 10 || p.length > 128) return false;
  return /[a-zA-Z]/.test(p) && /[0-9]/.test(p); // au moins une lettre et un chiffre
}

async function readJson(req) {
  const ct = (req.headers.get("content-type") || "").toLowerCase();
  if (!ct.includes("application/json")) return null;
  const len = parseInt(req.headers.get("content-length") || "0", 10);
  if (len > MAX_BODY_BYTES) return null;
  try {
    const txt = await req.text();
    if (txt.length > MAX_BODY_BYTES) return null;
    return JSON.parse(txt);
  } catch (e) {
    return null;
  }
}

/** Anti-CSRF : Origin cohérente (si fournie) + header custom X-Requested-With. */
function sameOriginOk(req) {
  const origin = req.headers.get("origin");
  if (origin) {
    try { if (new URL(origin).host !== new URL(req.url).host) return false; } catch (e) { return false; }
  }
  return (req.headers.get("x-requested-with") || "").toLowerCase() === "xmlhttprequest";
}

// --------------------------------------------------------------------------
// Proxy d'audit durci (GET passif uniquement, anti-SSRF)
// --------------------------------------------------------------------------
const PRIVATE_HOST_PATTERNS = [
  /^localhost$/i,
  /\.localhost$/i,
  /\.local$/i,
  /\.internal$/i,
  /\.lan$/i,
  /\.home\.arpa$/i,
];

const PROXY_FORWARD_HEADERS = [
  "content-type", "content-length", "location",
  "content-security-policy", "strict-transport-security",
  "x-frame-options", "x-content-type-options", "referrer-policy",
  "permissions-policy", "cross-origin-opener-policy",
  "server", "x-powered-by", "x-aspnet-version",
  "access-control-allow-origin", "access-control-allow-credentials",
  "set-cookie",
];

function parseIPv4(host) {
  const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(host);
  if (!m) return null;
  const o = m.slice(1).map(Number);
  if (o.some(x => x > 255)) return null;
  return o;
}

function isPrivateIPv4(o) {
  const [a, b] = o;
  if (a === 0 || a === 10 || a === 127) return true;            // this-network, privé, loopback
  if (a === 169 && b === 254) return true;                        // link-local + 169.254.169.254 (metadata cloud)
  if (a === 172 && b >= 16 && b <= 31) return true;               // privé
  if (a === 192 && b === 168) return true;                        // privé
  if (a === 192 && b === 0) return true;                          // 192.0.0.0/24 + 192.0.2.0/24
  if (a === 100 && b >= 64 && b <= 127) return true;              // CGNAT
  if (a === 198 && (b === 18 || b === 19)) return true;           // benchmark
  if (a >= 224) return true;                                      // multicast + réservé
  return false;
}

function expandIPv6(host) {
  let h = host.replace(/^\[|\]$/g, "").toLowerCase();
  if (h.includes("%")) return null; // zone
  const dbl = h.indexOf("::");
  if (dbl >= 0) {
    const parts = h.split("::");
    if (parts.length > 2) return null;
    const left = parts[0] ? parts[0].split(":") : [];
    const right = parts[1] ? parts[1].split(":") : [];
    const fill = 8 - left.length - right.length;
    if (fill < 0) return null;
    h = [...left, ...Array(fill).fill("0"), ...right].join(":");
  }
  const groups = h.split(":");
  if (groups.length !== 8) return null;
  const out = [];
  for (const g of groups) {
    if (!/^[0-9a-f]{1,4}$/.test(g)) return null;
    out.push(parseInt(g, 16));
  }
  return out;
}

/** true si l'hôte est privé/réservé (interdit pour le proxy). */
function isPrivateHost(hostname) {
  const h = String(hostname || "").trim().toLowerCase().replace(/\.$/, "");
  if (!h) return true;
  if (PRIVATE_HOST_PATTERNS.some(re => re.test(h))) return true;
  const v4 = parseIPv4(h);
  if (v4) return isPrivateIPv4(v4);
  if (h.includes(":")) {
    const g = expandIPv6(h);
    if (!g) return true; // illisible → refus
    if (g.every(x => x === 0)) return true;                       // ::
    if (g[0] === 0 && g[1] === 0 && g[2] === 0 && g[3] === 0 && g[4] === 0 && g[5] === 0 && g[6] === 0 && g[7] === 1) return true; // ::1
    if ((g[0] & 0xfe00) === 0xfc00) return true;                  // fc00::/7
    if ((g[0] & 0xffc0) === 0xfe80) return true;                  // fe80::/10
    if (g[0] === 0 && g[1] === 0 && g[2] === 0 && g[3] === 0 && g[4] === 0 && g[5] === 0xffff) {
      return isPrivateIPv4([g[6] >> 8, g[6] & 255, g[7] >> 8, g[7] & 255]); // ::ffff:v4
    }
  }
  return false;
}

async function fetchWithTimeout(url, method) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), PROXY_TIMEOUT_MS);
  try {
    return await fetch(url, { method, redirect: "manual", signal: ctrl.signal });
  } finally {
    clearTimeout(t);
  }
}

function buildProxyResponse(resp, finalUrl) {
  const h = {
    "Cache-Control": "no-store",
    "X-KS-Proxied": "1",
    "X-KS-Final-URL": String(finalUrl).slice(0, 500),
    ...SECURITY_HEADERS,
  };
  for (const name of PROXY_FORWARD_HEADERS) {
    let v;
    if (name === "set-cookie") {
      const many = typeof resp.headers.getSetCookie === "function" ? resp.headers.getSetCookie() : [];
      v = many.length ? many.join(" || ") : resp.headers.get("set-cookie");
    } else {
      v = resp.headers.get(name);
    }
    if (v !== null && v !== undefined) h["X-KS-H-" + name] = String(v).slice(0, 2000);
  }
  return resp.arrayBuffer().then(buf => {
    const capped = buf.byteLength > PROXY_MAX_BYTES ? buf.slice(0, PROXY_MAX_BYTES) : buf;
    if (h["X-KS-H-Content-Length"]) h["X-KS-H-Content-Length"] = String(capped.byteLength);
    return new Response(capped, { status: resp.status, headers: h });
  }).catch(() => new Response("proxy read error", { status: 502, headers: h }));
}

async function apiProxy(env, req, session) {
  if (!session) return json({ error: "Authentification requise." }, 401);
  if (req.method !== "GET" && req.method !== "HEAD") return json({ error: "Méthode non autorisée (GET passif uniquement)." }, 405);

  const u = new URL(req.url);
  const raw = u.searchParams.get("url");
  if (!raw) return json({ error: "Paramètre url manquant." }, 400);

  let target;
  try { target = new URL(raw); } catch (e) { return json({ error: "URL invalide." }, 400); }
  if (target.protocol !== "http:" && target.protocol !== "https:") {
    return json({ error: "Protocole refusé (http/https uniquement)." }, 400);
  }
  if (isPrivateHost(target.hostname)) {
    return json({ error: "Hôte refusé (réseau privé / interne)." }, 403);
  }
  // Pas d'identifiants dans l'URL
  if (target.username || target.password) return json({ error: "Identifiants dans l'URL refusés." }, 400);

  const method = req.method === "HEAD" ? "HEAD" : "GET";

  try {
    let current = target;
    let resp = await fetchWithTimeout(current.toString(), method);

    if (u.searchParams.get("noredir") !== "1") {
      let hops = 0;
      while (resp.status >= 300 && resp.status < 400 && hops < PROXY_MAX_REDIRECTS) {
        const loc = resp.headers.get("location");
        if (!loc) break;
        let next;
        try { next = new URL(loc, current); } catch (e) { break; }
        if (next.protocol !== "http:" && next.protocol !== "https:") break;
        if (isPrivateHost(next.hostname)) break;
        current = next;
        hops++;
        resp = await fetchWithTimeout(current.toString(), method);
      }
    }
    return await buildProxyResponse(resp, current.toString());
  } catch (e) {
    return json({ error: "Proxy : cible injoignable ou timeout." }, 502);
  }
}

// --------------------------------------------------------------------------
// Endpoints d'authentification
// --------------------------------------------------------------------------
async function apiRegister(env, req) {
  const body = await readJson(req);
  if (!body) return json({ error: "Requête invalide." }, 400);

  const email = normEmail(body.email);
  const password = typeof body.password === "string" ? body.password : "";
  const name = String(body.name || "").trim().slice(0, 80);

  if (!validEmail(email)) return json({ error: "Courriel invalide." }, 400);
  if (!validPassword(password)) return json({ error: "Mot de passe invalide : 10 caractères minimum, au moins une lettre et un chiffre." }, 400);

  const existing = await q1(env, "SELECT id FROM users WHERE email = ?", [email]);
  if (existing) return json({ error: "Un compte existe déjà avec ce courriel." }, 409);

  const id = newId();
  const hash = await hashPassword(password, env);
  await run(env,
    "INSERT INTO users(id, email, name, role, password_hash, created_at, status) VALUES(?,?,?,?,?,?,'active')",
    [id, email, name, "admin", hash, Math.floor(Date.now() / 1000)]);

  const sess = await createSession(env, req, id);
  return json({ user: { id, email, name, role: "admin" } }, 201, { "Set-Cookie": setCookie(sess.token, SESSION_TTL_S) });
}

async function apiLogin(env, req) {
  const body = await readJson(req);
  if (!body) return json({ error: "Requête invalide." }, 400);

  const email = normEmail(body.email);
  const password = typeof body.password === "string" ? body.password : "";
  const ip = clientIp(req);

  // Limitation de débit AVANT toute vérification (courriel + IP)
  const okEmail = await rateHit(env, "login:email:" + email, RATE_MAX_PER_EMAIL);
  const okIp = await rateHit(env, "login:ip:" + ip, RATE_MAX_PER_IP);
  if (!okEmail || !okIp) {
    return json({ error: "Trop de tentatives. Réessayez dans 15 minutes." }, 429, { "Retry-After": "900" });
  }

  const row = await q1(env, "SELECT id, email, name, role, password_hash, status FROM users WHERE email = ?", [email]);
  if (!row) {
    // Vérification factice pour uniformiser le temps de réponse
    await verifyPassword(password, "pbkdf2$210000$" + b64(new Uint8Array(16)) + "$" + b64(new Uint8Array(32)));
    return json({ error: "Identifiants invalides." }, 401);
  }
  const good = await verifyPassword(password, row.password_hash);
  if (!good || row.status !== "active") return json({ error: "Identifiants invalides." }, 401);

  await rateReset(env, "login:email:" + email); // succès : on repart à zéro pour ce courriel
  const sess = await createSession(env, req, row.id); // session neuve à chaque connexion
  return json({ user: publicUser(row) }, 200, { "Set-Cookie": setCookie(sess.token, SESSION_TTL_S) });
}

async function apiLogout(env, req, session) {
  if (session) await run(env, "DELETE FROM sessions WHERE token_hash = ?", [session.tokenHash]);
  return json({ ok: true }, 200, { "Set-Cookie": clearCookieHeader() });
}

async function apiMe(env, req, session) {
  if (!session) return json({ error: "Non authentifié." }, 401);
  const headers = {};
  if (session.rotatedToken) headers["Set-Cookie"] = setCookie(session.rotatedToken, SESSION_TTL_S);
  return json({ user: session.user }, 200, headers);
}

async function apiChangePassword(env, req, session) {
  if (!session) return json({ error: "Non authentifié." }, 401);
  const body = await readJson(req);
  if (!body) return json({ error: "Requête invalide." }, 400);

  const current = typeof body.currentPassword === "string" ? body.currentPassword : "";
  const next = typeof body.newPassword === "string" ? body.newPassword : "";
  if (!validPassword(next)) return json({ error: "Nouveau mot de passe invalide : 10 caractères minimum, au moins une lettre et un chiffre." }, 400);
  if (current === next) return json({ error: "Le nouveau mot de passe doit être différent." }, 400);

  const row = await q1(env, "SELECT id, password_hash FROM users WHERE id = ?", [session.user.id]);
  if (!row) return json({ error: "Non authentifié." }, 401);

  const good = await verifyPassword(current, row.password_hash);
  if (!good) return json({ error: "Mot de passe actuel incorrect." }, 401);

  const hash = await hashPassword(next, env);
  await run(env, "UPDATE users SET password_hash = ? WHERE id = ?", [hash, row.id]);
  await deleteAllSessions(env, row.id); // toutes les sessions invalidées

  const sess = await createSession(env, req, row.id); // nouvelle session post-rotation
  return json({ ok: true, user: session.user }, 200, { "Set-Cookie": setCookie(sess.token, SESSION_TTL_S) });
}

// --------------------------------------------------------------------------
// Routage principal
// --------------------------------------------------------------------------
async function handle(req, env) {
  const url = new URL(req.url);
  const path = url.pathname;

  if (path === "/api/auth/register" && req.method === "POST") {
    if (!sameOriginOk(req)) return json({ error: "Requête refusée (CSRF)." }, 403);
    return apiRegister(env, req);
  }
  if (path === "/api/auth/login" && req.method === "POST") {
    if (!sameOriginOk(req)) return json({ error: "Requête refusée (CSRF)." }, 403);
    return apiLogin(env, req);
  }
  if (path === "/api/auth/logout" && req.method === "POST") {
    if (!sameOriginOk(req)) return json({ error: "Requête refusée (CSRF)." }, 403);
    const s = await getSession(env, req);
    return apiLogout(env, req, s);
  }
  if (path === "/api/auth/change-password" && req.method === "POST") {
    if (!sameOriginOk(req)) return json({ error: "Requête refusée (CSRF)." }, 403);
    const s = await getSession(env, req);
    return apiChangePassword(env, req, s);
  }
  if (path === "/api/auth/me" && req.method === "GET") {
    const s = await getSession(env, req);
    return apiMe(env, req, s);
  }
  if (path === "/api/proxy") {
    const s = await getSession(env, req);
    return apiProxy(env, req, s);
  }
  if (path.startsWith("/api/")) return json({ error: "Route inconnue." }, 404);

  // Tout le reste : fichiers statiques, avec les headers de sécurité
  if (req.method !== "GET" && req.method !== "HEAD") {
    return json({ error: "Méthode non autorisée." }, 405);
  }
  let resp;
  try {
    resp = await env.ASSETS.fetch(req);
  } catch (e) {
    return json({ error: "Asset indisponible." }, 500);
  }
  if (!resp) return json({ error: "Introuvable." }, 404);
  const headers = new Headers(resp.headers);
  for (const [k, v] of Object.entries(SECURITY_HEADERS)) headers.set(k, v);
  return new Response(resp.body, { status: resp.status, headers });
}

export default {
  async fetch(request, env, ctx) {
    try {
      await housekeeping(env);
      return await handle(request, env);
    } catch (err) {
      return json({ error: "Erreur interne." }, 500);
    }
  },
};
