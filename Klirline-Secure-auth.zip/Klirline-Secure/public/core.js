// KlirSecure — noyau partagé (était un script inline dans index.html)
// Le repli proxy passe désormais par le Worker durci (/api/proxy), qui exige
// une session valide. Les headers de sécurité de la cible sont renvoyés
// préfixés X-KS-H- (reconstruits par fetchText dans app.js).
window.root = window.root || {};
window.root.kv = null;
window.root.sessionUser = null; // renseigné par auth.js

window.root.superFetch = async function (url, opt) {
  opt = opt || {};
  try {
    const r = await fetch(url, opt);
    return r;
  } catch (e) {
    // Repli proxy : GET passif uniquement, cible validée côté serveur.
    if ((opt.method || "GET").toUpperCase() !== "GET") throw e;
    let prox = "/api/proxy?url=" + encodeURIComponent(url);
    if (opt.ksManualRedirect) prox += "&noredir=1";
    return await fetch(prox, { method: "GET" });
  }
};

window.root.generateText = async function () { return "(IA desactivee en version statique)"; };
