// ============================================================================
// KlirSecure — Passerelle d'authentification (connexion / création de compte)
// Bloque l'accès à l'application tant qu'aucune session valide n'existe.
// ============================================================================
(function () {
  const AH = { "X-Requested-With": "XMLHttpRequest", "Content-Type": "application/json" };
  let mode = "login"; // "login" | "register"
  let gate = null;

  window.root = window.root || {};

  async function call(method, path, body) {
    const r = await fetch(path, {
      method: method,
      headers: AH,
      body: body ? JSON.stringify(body) : undefined,
      credentials: "same-origin",
    });
    let j = null;
    try { j = await r.json(); } catch (e) { /* réponse non JSON */ }
    return { status: r.status, ok: r.ok, data: j };
  }

  // Résout true si une session valide existe ; sinon affiche l'écran de connexion
  // et résout false — root.afterAuth() sera appelé après une connexion réussie.
  async function ensure() {
    try {
      const r = await fetch("/api/auth/me", { headers: AH, credentials: "same-origin" });
      if (r.ok) {
        const j = await r.json();
        if (j && j.user) { root.sessionUser = j.user; return true; }
      }
    } catch (e) { /* réseau */ }
    showGate();
    return false;
  }

  function el(id) { return gate.querySelector(id); }

  function showGate() {
    if (!gate) buildGate();
    gate.hidden = false;
    setTimeout(function () { try { el("#authEmail").focus(); } catch (e) {} }, 50);
  }

  function hideGate() {
    if (gate) gate.hidden = true;
  }

  function buildGate() {
    gate = document.createElement("div");
    gate.id = "authGate";
    gate.innerHTML =
      '<div class="authBox">' +
      '<div class="logo" style="justify-content:center"><div class="shield">K</div><div>KLIRSECURE<small>ACCÈS AUX COMPTES</small></div></div>' +
      '<div class="tabs" style="justify-content:center"><button type="button" id="tabLogin" class="on">Connexion</button><button type="button" id="tabReg">Créer un compte</button></div>' +
      '<form id="authForm" novalidate>' +
      '<label class="mut" style="display:block;font-size:11px;text-transform:uppercase;letter-spacing:1px" id="nameLbl" hidden>Nom (optionnel)</label>' +
      '<input type="text" id="regName" placeholder="Votre nom" maxlength="80" hidden autocomplete="name">' +
      '<label class="mut" style="display:block;font-size:11px;text-transform:uppercase;letter-spacing:1px">Courriel</label>' +
      '<input type="email" id="authEmail" placeholder="vous@entreprise.com" required maxlength="254" autocomplete="username">' +
      '<label class="mut" style="display:block;font-size:11px;text-transform:uppercase;letter-spacing:1px;margin-top:8px">Mot de passe</label>' +
      '<input type="password" id="authPass" required maxlength="128" autocomplete="current-password" placeholder="10 caractères min., lettre + chiffre">' +
      '<div class="authErr" id="authErr" hidden></div>' +
      '<button type="submit" class="btn" id="authSubmit" style="width:100%;margin-top:12px">Se connecter</button>' +
      '</form>' +
      '<div class="mut" style="font-size:11px;margin-top:12px;text-align:center">Sessions chiffrées · cookie HttpOnly · limitation anti-brute-force.<br>Vos audits restent stockés sur votre appareil.</div>' +
      '</div>';
    document.body.appendChild(gate);

    el("#tabLogin").onclick = function () { setMode("login"); };
    el("#tabReg").onclick = function () { setMode("register"); };
    el("#authForm").onsubmit = submit;
  }

  function setMode(m) {
    mode = m;
    const reg = m === "register";
    el("#tabLogin").classList.toggle("on", !reg);
    el("#tabReg").classList.toggle("on", reg);
    el("#regName").hidden = !reg;
    el("#nameLbl").hidden = !reg;
    el("#authSubmit").textContent = reg ? "Créer mon compte" : "Se connecter";
    el("#authPass").setAttribute("autocomplete", reg ? "new-password" : "current-password");
    el("#authErr").hidden = true;
  }

  function showError(msg) {
    const e = el("#authErr");
    e.textContent = msg;
    e.hidden = false;
  }

  async function submit(ev) {
    ev.preventDefault();
    const email = el("#authEmail").value.trim();
    const password = el("#authPass").value;
    const name = el("#regName").value.trim();
    const btn = el("#authSubmit");
    btn.disabled = true;
    btn.textContent = mode === "register" ? "Création…" : "Connexion…";
    try {
      const res = mode === "register"
        ? await call("POST", "/api/auth/register", { email: email, password: password, name: name })
        : await call("POST", "/api/auth/login", { email: email, password: password });

      if (res.ok && res.data && res.data.user) {
        root.sessionUser = res.data.user;
        hideGate();
        if (typeof root.afterAuth === "function") root.afterAuth();
        return;
      }
      const msg = (res.data && res.data.error) || "Échec de l'authentification.";
      showError(msg);
    } catch (e) {
      showError("Serveur injoignable. Réessayez.");
    } finally {
      btn.disabled = false;
      btn.textContent = mode === "register" ? "Créer mon compte" : "Se connecter";
    }
  }

  root.auth = {
    ensure: ensure,
    logout: async function () {
      try { await call("POST", "/api/auth/logout"); } catch (e) { /* ignore */ }
      root.sessionUser = null;
      location.reload();
    },
  };
})();
