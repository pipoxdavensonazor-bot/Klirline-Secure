-- ============================================================================
-- KlirSecure — Schéma D1 (SQLite) pour l'authentification des comptes
-- Appliquer : wrangler d1 execute klirsecure --remote --file schema.sql
-- ============================================================================

CREATE TABLE IF NOT EXISTS users (
  id            TEXT PRIMARY KEY,              -- UUID
  email         TEXT NOT NULL UNIQUE,          -- normalisé (minuscules, trim)
  name          TEXT NOT NULL DEFAULT '',
  role          TEXT NOT NULL DEFAULT 'admin', -- admin / auditeur / lecteur
  password_hash TEXT NOT NULL,                -- pbkdf2$<iterations>$<salt>$<hash>
  created_at    INTEGER NOT NULL,              -- epoch secondes
  status        TEXT NOT NULL DEFAULT 'active' -- active / suspended
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- Sessions serveur : seul le SHA-256 du jeton est stocké.
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id    TEXT NOT NULL REFERENCES users(id),
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  ip         TEXT,
  ua         TEXT
);

CREATE INDEX IF NOT EXISTS idx_sessions_user  ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_exp   ON sessions(expires_at);

-- Compteurs de limitation de débit (fenêtre 15 min).
CREATE TABLE IF NOT EXISTS rate_limit (
  k            TEXT PRIMARY KEY,   -- ex. login:email:x@y.z  /  login:ip:1.2.3.4
  window_start INTEGER NOT NULL,
  count        INTEGER NOT NULL
);
